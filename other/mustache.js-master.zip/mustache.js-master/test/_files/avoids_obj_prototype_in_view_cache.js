({
  valueOf: 'Avoids methods',
  watch: 'in Object.prototype'
})
